package com.serifgungor.alarmmanagerkullanimi;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    AlarmManager alarmMgr;
    PendingIntent pendingIntent;

    public void startAlarmManager()
    {
        Intent dialogIntent = new Intent(getBaseContext(), AlarmReceiver.class);

        alarmMgr = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
        pendingIntent = PendingIntent.getBroadcast(this, 0, dialogIntent,PendingIntent.FLAG_CANCEL_CURRENT);

        alarmMgr.setInexactRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis(), 3000, pendingIntent);

    }
    public void stopAlarmManager()
    {
        if(alarmMgr != null)
            alarmMgr.cancel(pendingIntent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startAlarmManager();
        //stopAlarmManager();
    }
}
