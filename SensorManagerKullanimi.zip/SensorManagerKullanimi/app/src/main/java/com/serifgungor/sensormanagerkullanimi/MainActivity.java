package com.serifgungor.sensormanagerkullanimi;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sm;
    private Sensor mysensor;

    @Override
    protected void onResume() {
        super.onResume();
        sm.registerListener(this, mysensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sm.unregisterListener(this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);

        List<Sensor> sensorler = sm.getSensorList(Sensor.TYPE_ALL);
        mysensor = sm.getDefaultSensor(Sensor.TYPE_LIGHT);

        StringBuilder sb = new StringBuilder("");

        for (Sensor s : sensorler) {
            sb.append(s.getName() + "");
            sb.append(s.getType() + "");
            sb.append(s.getVersion() + "");
            sb.append(s.getVendor() + "");
            Log.d("SENSOR_LOG", sb.toString());
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Log.d("SENSOR_LOG_1", "Şuanki sensör: " + event.sensor.getName());
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}