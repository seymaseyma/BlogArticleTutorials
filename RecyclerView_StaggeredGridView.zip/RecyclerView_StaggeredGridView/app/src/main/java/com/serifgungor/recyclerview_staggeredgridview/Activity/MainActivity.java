package com.serifgungor.recyclerview_staggeredgridview.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;

import com.serifgungor.recyclerview_staggeredgridview.Adapter.Photo_Adapter;
import com.serifgungor.recyclerview_staggeredgridview.Model.Photo;
import com.serifgungor.recyclerview_staggeredgridview.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    Photo_Adapter adapter;
    List<Photo> photos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        photos = new ArrayList<>();
        /*
        int id, String photoUrl, String photoTitle, String userPhotoUrl, String userName, String userDescription
         */
        photos.add(
                new Photo(1, "https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "Penguen", "https://images.unsplash.com/photo-1544817286-c8934b4f3c3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "username", "açıklama")
        );
        photos.add(
                new Photo(1, "https://images.unsplash.com/photo-1544828115-333cdae6b7c3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "Street", "https://images.unsplash.com/photo-1544828115-333cdae6b7c3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "username", "açıklama")
        );
        photos.add(
                new Photo(1, "https://images.unsplash.com/photo-1544808728-35c5958efd93?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "Train", "https://images.unsplash.com/photo-1544808728-35c5958efd93?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "username", "açıklama")
        );
        photos.add(
                new Photo(1, "https://images.unsplash.com/photo-1544842413-05944bc01da2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "Taksi", "https://images.unsplash.com/photo-1544842413-05944bc01da2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "username", "açıklama")
        );
        photos.add(
                new Photo(1, "https://images.unsplash.com/photo-1544828115-333cdae6b7c3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "Street", "https://images.unsplash.com/photo-1544828115-333cdae6b7c3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "username", "açıklama")
        );
        photos.add(
                new Photo(1, "https://images.unsplash.com/photo-1544842413-05944bc01da2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "Taksi", "https://images.unsplash.com/photo-1544842413-05944bc01da2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60", "username", "açıklama")
        );

        recyclerView = findViewById(R.id.recyclerView);
        adapter = new Photo_Adapter(photos);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(adapter);
    }
}