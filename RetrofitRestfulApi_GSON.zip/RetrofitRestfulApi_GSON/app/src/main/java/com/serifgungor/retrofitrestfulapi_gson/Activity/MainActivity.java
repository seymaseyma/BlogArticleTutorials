package com.serifgungor.retrofitrestfulapi_gson.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.serifgungor.retrofitrestfulapi_gson.Adapter.ListViewAdapter;
import com.serifgungor.retrofitrestfulapi_gson.Helper.ApiClient;
import com.serifgungor.retrofitrestfulapi_gson.Interface.ApiInterface;
import com.serifgungor.retrofitrestfulapi_gson.Model.Blog;
import com.serifgungor.retrofitrestfulapi_gson.Model.BlogResponse;
import com.serifgungor.retrofitrestfulapi_gson.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ListViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        ApiInterface apiService =ApiClient.getClient().create(ApiInterface.class);

        Call<BlogResponse> call = apiService.getBloglar();
        call.enqueue(new Callback<BlogResponse>() {
            @Override
            public void onResponse(Call<BlogResponse> call, Response<BlogResponse> response) {
                if (response.isSuccessful()) {
                    List<Blog> bloglar = response.body().getGetBlogs();

                    adapter = new ListViewAdapter(getApplicationContext(),bloglar);
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<BlogResponse> call, Throwable t) {

            }
        });

    }
}