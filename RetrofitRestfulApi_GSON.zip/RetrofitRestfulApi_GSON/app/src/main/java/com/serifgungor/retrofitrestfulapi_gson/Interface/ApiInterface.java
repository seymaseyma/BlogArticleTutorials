package com.serifgungor.retrofitrestfulapi_gson.Interface;

import com.serifgungor.retrofitrestfulapi_gson.Model.BlogResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {
    @Headers("Content-Type: application/json")
    @POST("content/api/post/blogs.php")
    Call<BlogResponse> getBloglar(); //@Query("api_key") String apiKey
}