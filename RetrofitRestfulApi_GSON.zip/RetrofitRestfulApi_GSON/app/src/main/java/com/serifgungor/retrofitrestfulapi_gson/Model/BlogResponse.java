package com.serifgungor.retrofitrestfulapi_gson.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BlogResponse {
    @SerializedName("blogs")
    public List<Blog> getBlogs;

    public List<Blog> getGetBlogs() {
        return getBlogs;
    }

    public void setGetBlogs(List<Blog> getBlogs) {
        this.getBlogs = getBlogs;
    }
}