package com.serifgungor.recyclerview_multipleviewholder.Model;

public class Reklam {
    private String reklamId;

    public Reklam() {
    }

    public Reklam(String reklamId) {
        this.reklamId = reklamId;
    }

    public String getReklamId() {
        return reklamId;
    }

    public void setReklamId(String reklamId) {
        this.reklamId = reklamId;
    }
}