package com.serifgungor.listactivitykullanimi;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends ListActivity {
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        //satırdaki yazı
        //Toast.makeText(this,l.getItemAtPosition(position).toString(),Toast.LENGTH_LONG).show();
        //satırın indisi
        //Toast.makeText(this,id+"",Toast.LENGTH_LONG).show();

        switch (position){
            case 0: Toast.makeText(this,"Ankara",Toast.LENGTH_LONG).show(); break;
            case 1: Toast.makeText(this,"Londra",Toast.LENGTH_LONG).show(); break;
            case 2: Toast.makeText(this,"Oslo",Toast.LENGTH_LONG).show(); break;
            case 3: Toast.makeText(this,"Madrid",Toast.LENGTH_LONG).show(); break;
            case 4: Toast.makeText(this,"Berlin",Toast.LENGTH_LONG).show(); break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] country = {"Türkiye","İngiltere","Norveç","İspanya","Almanya"};
        setListAdapter( new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,country));
    }

}